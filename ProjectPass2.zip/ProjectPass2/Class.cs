﻿namespace ProjectPass2
{
    public class Class
    {

        public string password { get; set; }
        public string salt { get; set; }
        public string hash { get; set; }
    }
}
