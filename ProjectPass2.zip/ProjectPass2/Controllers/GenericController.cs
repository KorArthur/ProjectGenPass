using Microsoft.AspNetCore.Mvc;

namespace ProjectPass2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class GenericController : ControllerBase
    {

        private readonly ILogger<GenericController> _logger;

        public GenericController(ILogger<GenericController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public Class Get(int ls, int lp)
        {
            Class _class = ClassPHS.Rezerv(ls, lp);
            return _class;
        }
    }
}